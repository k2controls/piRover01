Awesome—here’s a **safe, repeatable pre-clone cleanup script** for Raspberry Pi OS. It removes logs, temp files, old DHCP leases, unique IDs (so each clone gets new ones), and more—without breaking directory structures. It also supports an optional “deep user cleanup” flag if you want to remove things like recent-file lists and browser caches.

Save as `/usr/local/sbin/rpi-preclone-clean.sh`, make it executable, then run with `sudo`.

```bash
#!/usr/bin/env bash
# rpi-preclone-clean.sh
# Pre-clone cleanup for Raspberry Pi OS (Bookworm+)
# Usage: sudo rpi-preclone-clean.sh [--deep-user-clean]

set -euo pipefail

DEEP_USER_CLEAN="${1:-}"

echo "==> Raspberry Pi OS pre-clone cleanup starting..."

# 0) Safety checks
if [[ $EUID -ne 0 ]]; then
  echo "ERROR: Please run as root (use sudo)."
  exit 1
fi

if systemctl is-system-running --quiet 2>/dev/null; then
  true
fi

# 1) APT tidy (assumes you already updated/upgraded before cloning)
echo "==> APT cleanup..."
apt-get -y autoremove --purge
apt-get -y clean
rm -rf /var/cache/apt/archives/*.deb || true

# 2) Logs (remove files only; keep directories and permissions intact)
echo "==> Clearing logs..."
find /var/log -type f -exec truncate -s 0 {} \; || true
# journal logs
journalctl --vacuum-time=1s || true

# 3) Temp files
echo "==> Clearing temp directories..."
rm -rf /tmp/* /var/tmp/* 2>/dev/null || true

# 4) DHCP leases (dhcpcd on Raspberry Pi OS)
echo "==> Clearing DHCP leases..."
rm -f /var/lib/dhcp/*.leases 2>/dev/null || true
rm -f /var/lib/dhcpcd5/* 2>/dev/null || true

# 5) SSH host keys (regenerate on first boot)
echo "==> Removing SSH host keys (will regenerate on first boot)..."
rm -f /etc/ssh/ssh_host_* 2>/dev/null || true

# 6) Machine IDs (regenerate on first boot)
echo "==> Resetting machine IDs..."
truncate -s 0 /etc/machine-id
rm -f /var/lib/dbus/machine-id 2>/dev/null || true

# 7) Shell history for all users (root + normal users)
echo "==> Clearing shell history..."
HIST_FILES=(
  "/root/.bash_history"
)
# Add each user's history file
for HOME_DIR in /home/*; do
  [[ -d "$HOME_DIR" ]] || continue
  HIST_FILES+=("$HOME_DIR/.bash_history" "$HOME_DIR/.zsh_history")
done
for hf in "${HIST_FILES[@]}"; do
  rm -f "$hf" 2>/dev/null || true
done

# 8) User caches and recent files (optional: --deep-user-clean)
if [[ "$DEEP_USER_CLEAN" == "--deep-user-clean" ]]; then
  echo "==> Deep user cleanup enabled (browser cache, recent files, thumbnails, etc.)"
  for HOME_DIR in /home/*; do
    [[ -d "$HOME_DIR" ]] || continue
    USERNAME="$(basename "$HOME_DIR")"

    # Common caches
    rm -rf "$HOME_DIR/.cache/"* 2>/dev/null || true
    rm -rf "$HOME_DIR/.thumbnails/"* 2>/dev/null || true
    rm -f  "$HOME_DIR/.local/share/recently-used.xbel" 2>/dev/null || true

    # Chromium/Chrome/Firefox caches (if present)
    rm -rf "$HOME_DIR/.cache/chromium/"* 2>/dev/null || true
    rm -rf "$HOME_DIR/.config/chromium/Default/Cache/"* 2>/dev/null || true
    rm -rf "$HOME_DIR/.cache/google-chrome/"* 2>/dev/null || true
    rm -rf "$HOME_DIR/.mozilla/firefox/"*.default*/cache2/* 2>/dev/null || true

    # PCManFM/LXDE recent items (if present)
    rm -rf "$HOME_DIR/.config/pcmanfm/"*/*/recent/* 2>/dev/null || true

    # Ensure ownership remains correct
    chown -R "$USERNAME:$USERNAME" "$HOME_DIR" 2>/dev/null || true
  done
fi

# 9) Remove leftover crash reports and cores
echo "==> Removing crash reports and core dumps..."
rm -rf /var/crash/* 2>/dev/null || true
find / -xdev -type f -name "core" -delete 2>/dev/null || true

# 10) Clear bash completion caches and misc noise
echo "==> Clearing misc caches..."
rm -rf /var/tmp/* /var/lib/systemd/coredump/* 2>/dev/null || true

# 11) Random seed (optional: will regenerate on boot)
echo "==> Resetting systemd random seed..."
rm -f /var/lib/systemd/random-seed 2>/dev/null || true

# 12) Ensure permissions on key dirs are sane
echo "==> Verifying key directory permissions..."
chmod 755 / /var /var/log /tmp /var/tmp || true
chmod 1777 /tmp /var/tmp || true

echo "==> Pre-clone cleanup complete."
echo "==> Recommended next step: 'sudo poweroff' before imaging."
```

**Make it executable & run it:**

```bash
sudo install -m 755 rpi-preclone-clean.sh /usr/local/sbin/
sudo /usr/local/sbin/rpi-preclone-clean.sh            # basic cleanup
# or
sudo /usr/local/sbin/rpi-preclone-clean.sh --deep-user-clean   # includes user caches/recent files
```

**Then:** shut down cleanly and image the card:

```bash
sudo poweroff
```

If you also want a **space-shrinking pass** (for smaller image files), run `zerofree` on the root partition—but do that **from another system** or a live USB, not the running Pi. I can add a companion script for that too if you’d like.
