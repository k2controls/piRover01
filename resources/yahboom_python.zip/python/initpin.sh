#!/bin/bash

gpio mode 0 input
gpio mode 1 input
gpio mode 2 input
gpio mode 3 input
gpio mode 4 input
gpio mode 5 input
gpio mode 6 input
gpio mode 7 input
gpio mode 8 input
gpio mode 9 input
gpio mode 10 input
gpio mode 11 input
gpio mode 12 input
gpio mode 13 input
gpio mode 14 input
gpio mode 15 input
gpio mode 16 input
gpio mode 21 input
gpio mode 22 input
gpio mode 23 input
gpio mode 24 input
gpio mode 25 input
gpio mode 26 input
gpio mode 27 input
gpio mode 28 input
gpio mode 29 input
